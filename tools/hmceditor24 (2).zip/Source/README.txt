Hitman: Contracts TEX Editor v2.4 Source Code                   MPL open source
�Copyright 2004 Alexande "Elbereth" Devilliers                       20-06-2004
===============================================================================

This source code can be used and modified if following the Mozilla Public
Licence 1.1. Read LICENCE.txt for more information.

Needed:
-------

You need a Delphi compiler. The Borland Delphi Personnal Edition (which is
free) version 6 or 7 will do the job.
You obviously also need some Delphi programming skills. :P

You need ZipMaster v1.73.
http://www.geocities.com/rjpeters_au/zipmaster.html

This version uses JclShell, JvProgressBar, JvSelectDirectory from the JVCL
v3.00 library.
http://jvcl.sourceforge.net

-------------------------------------------------------------------------------

resample.pas : bitmap resampler v1.02 by Anders Melander
               Fixed 2 small bugs to use it with HMCEditor.

spec_DDS.pas : based on information provided on the following Microsoft page:
               http://msdn.microsoft.com/library/default.asp?url=/library/en-us
               /directx9_c/directx/graphics/reference/ddsfilereference/ddsfilef
               ormat.asp

class_xbox.pas : translated from unswizzle.cpp code by aman.

This version lacks source comments.

===============================================================================